# Hoja de Vida
### **Emanuel Obredor Vasquez** ###

![foto de perfil](https://avatars.githubusercontent.com/u/110873019?s=400&u=a0a82670a17ec6d520bbc36f614fd9a8fb421e0b&v=)
## DATOS PERSONALES ##
**NOMBRES:** Emanuel Jesús  
**APELLIDOS:** Obredor Vasquez  
**FECHA DE NACIMIENTO:** 09/22/2004  
**LUGAR DE NACIMIENTO:** Barranquilla, Átlantico  
**NÚMERO DE IDENTIFICACIÓN:** 1043662882  
**NÚMERO DE CONTACTO:** 3026482695  
**DIRECCIÓN DE RESIDENCIA:** Cra 6m #101 87  
## COMPETENCIAS ##
- Trabajo en equipo
- Comunicación activa
- Inglés básico
## EDUCACIÓN ##
**BÁSICA PRIMARIA:**
- Institución Educativa Distrital Pestalozzi
- Institución Educativa Distrital Meira Delmar
- Escuela Normal Superior "La Hacienda"  

**BÁSICA SECUNDARIA:**
- Escuela Normal Superior "La Hacienda"  

**MEDIA VOCACIONAL:**  
- Escuela Normal Superior "La Hacienda"
## TÍTULOS OBTENIDOS
- Bachiller con Profundización en Pedagogía
## INTERESESES Y HOBBIES ##
- Música
- Escritura Creativa
- Viajar 
